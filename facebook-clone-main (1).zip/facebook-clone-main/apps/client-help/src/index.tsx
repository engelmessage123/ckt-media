import { render } from 'react-dom';
import "./styles/globals.css";
import App from './App';

render(<App />, document.getElementById('root'));
