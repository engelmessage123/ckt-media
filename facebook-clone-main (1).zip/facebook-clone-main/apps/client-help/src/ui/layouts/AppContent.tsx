import { styled } from "../../lib/stitches.config";

export const AppContentLayout = styled("div", {
    paddingTop : "$from-header"
})