const Facebook = () => (
  <img
    src="/assets/icons/favicon.ico"
    alt="facebook help center logo"
    width="35"
    onClick={() => (window.location.href = "/")}
  />
);

export default Facebook;
