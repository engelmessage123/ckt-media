
export const theme = {
    styles: {
        global: {
            'html, body': {
                color: 'white',
                background: "black"
            },
        },
    },
}