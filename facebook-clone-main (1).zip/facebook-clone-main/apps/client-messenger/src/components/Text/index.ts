export { default as TextBaseHighlighted } from "./TextBaseHighlighted"
