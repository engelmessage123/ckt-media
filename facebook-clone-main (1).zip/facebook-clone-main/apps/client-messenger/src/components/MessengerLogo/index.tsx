//@ts-ignore
import logo from "../../assets/images/logo.svg"

const MessengerLogo = () => {
  return <img src={logo} width="70" alt="" />
}

export default MessengerLogo
