import { FC } from "react";

type ChatRoomMessageActivityProps = {
  date?: string;
};

const ChatRoomMessageActivity: FC<ChatRoomMessageActivityProps> = ({}) => {
  return <div>ChatRoomMessageActivity</div>;
};

export default ChatRoomMessageActivity;
