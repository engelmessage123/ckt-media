export const KEY_API = "";
export const KEY_STORAGE = "";
export const API_KEY = "2000-key";
export const { WEATHER_KEY } = process.env;
