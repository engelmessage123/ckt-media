import ContainerMainNavigator from "@fb-containers/ContainerMainNavigator";

const MessagesUserId = () => <ContainerMainNavigator />;

export default MessagesUserId;
