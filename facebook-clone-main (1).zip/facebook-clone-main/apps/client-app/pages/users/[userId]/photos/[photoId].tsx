export default function UserPhotosPulication() {
  return <div />;
}
