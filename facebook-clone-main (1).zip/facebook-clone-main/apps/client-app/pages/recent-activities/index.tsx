export default function RecentActivities() {
  return <div>activities</div>;
}
