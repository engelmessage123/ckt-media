import SignInView from "@views/SignInView";

export default function SignIn() {
  return <SignInView />;
}
