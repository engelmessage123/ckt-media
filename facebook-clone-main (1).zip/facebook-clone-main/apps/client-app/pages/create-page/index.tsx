export default function CreatePage() {
  return <div />;
}
