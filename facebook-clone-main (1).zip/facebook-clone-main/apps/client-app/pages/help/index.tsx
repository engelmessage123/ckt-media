import HelpView from "@views/HelpView";

export default function Help() {
  return <HelpView />;
}
