import React from "react";

const CreateNewPageView = () => <div />;

export default CreateNewPageView;
