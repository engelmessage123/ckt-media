import React from "react";

const MessagesView = () => <div />;

export default MessagesView;
