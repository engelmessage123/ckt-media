import React from "react";

const RecentActivitiesView = () => <div />;

export default RecentActivitiesView;
