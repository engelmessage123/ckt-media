import React from "react";

const JobsView = () => <div />;

export default JobsView;
