export { default as marketplaceMocks } from "./marketplaceMocks";
export { default as contactsMocks } from "./contactsMocks";
export { default as postsMocks } from "./postsMocks";
export { default as usersMocks } from "./usersMocks";
export { default as watchMocks } from "./watchMocks";
export { default as storiesMocks } from "./storiesMocks";
export { default as peopleSearchResult } from "./peopleSearchResult";

/**
 * accounts
 * user profile
 */
