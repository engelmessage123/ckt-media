import ContainerOnlineContactFriendsList from "./ContainerOnlineContactFriendsList";

export default () => <ContainerOnlineContactFriendsList />;
