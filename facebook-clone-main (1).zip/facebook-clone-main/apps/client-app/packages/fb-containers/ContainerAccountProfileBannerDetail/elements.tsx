import styled from "styled-components";

const MainWrapperAccountProfile = styled.div`
  .profile__pagelet {
    width: 70%;
    margin-left: auto;
    margin-right: auto;
  }
`;

export default MainWrapperAccountProfile;
