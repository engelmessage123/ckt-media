import OptionsNavigationList from "@fb-components/layouts/OptionsNavigationList";

const ContainerOptionsNavigation = () => <OptionsNavigationList />;

export default ContainerOptionsNavigation;
