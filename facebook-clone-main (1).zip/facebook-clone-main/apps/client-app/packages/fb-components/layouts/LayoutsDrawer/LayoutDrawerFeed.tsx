import styled from "styled-components";

export default styled.div`
  width: ${(props) => props.theme.layoutSizes.widthFeeds};
  margin: 2em auto 0;
`;
