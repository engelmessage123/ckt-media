import styled from "styled-components";

export default styled.div`
  margin: 2em auto;
  width: ${(props) => props.theme.layoutSizes.widthStories};
`;
