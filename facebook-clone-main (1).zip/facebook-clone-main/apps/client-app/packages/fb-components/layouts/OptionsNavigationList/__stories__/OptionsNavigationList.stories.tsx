import { Meta } from "@storybook/react/types-6-0";
import OptionsNavigationList from "..";

export default {
  title: "Layouts/OptionsNavigationList",
  component: OptionsNavigationList
} as Meta;

export const Default = () => <OptionsNavigationList />;
