export const InstaStoryPosition = "15px";
