import SquareImage from "@fb-components/common/SquareImage";
import styled from "styled-components";

export default styled(SquareImage)`
  width: 100%;
  height: 180px;
`;
