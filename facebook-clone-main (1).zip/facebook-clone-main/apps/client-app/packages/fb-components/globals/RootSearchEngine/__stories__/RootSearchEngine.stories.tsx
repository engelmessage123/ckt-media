import { Meta } from "@storybook/react/types-6-0";
import RootSearchEngine from "..";

export default {
  title: "Globals/RootSearchEngine",
  component: RootSearchEngine
} as Meta;

export const Default = () => <RootSearchEngine />;
