import { Meta } from "@storybook/react/types-6-0";
import ModalMoreOptionsAccount from "..";

export default {
  title: "Globals/ModalMoreOptionsAccount",
  component: ModalMoreOptionsAccount
} as Meta;

export const Default = () => <ModalMoreOptionsAccount />;
