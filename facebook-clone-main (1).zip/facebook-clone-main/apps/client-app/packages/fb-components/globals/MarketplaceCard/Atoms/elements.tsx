import styled from "styled-components";
import Wrapper from "@fb-components/common/Wrapper";

export const MarketplaceCardWrapper = styled(Wrapper)`
  width: 300px;
  cursor: pointer;
`;
