import { Meta } from "@storybook/react/types-6-0";
import Navigation from "..";

export default {
  title: "Globals/Navigation",
  component: Navigation
} as Meta;

export const Default = () => <Navigation />;
