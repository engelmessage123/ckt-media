import { Meta } from "@storybook/react/types-6-0";
import LinksPrivacityApplication from "..";

export default {
  title: "Application/LinksPrivacityApplication",
  component: LinksPrivacityApplication
} as Meta;

export const Default = () => <LinksPrivacityApplication />;
