import React from "react";
import TextLabel from "@fb-components/common/TextLabel";

const LinksPrivacityApplication = () => (
  <TextLabel textSize={200}>
    Privacity - Terms - Advertising - Ad Choices - Cookies - More - Facebook
    2020
  </TextLabel>
);

export default LinksPrivacityApplication;
