import { Meta } from "@storybook/react/types-6-0";
import RaisedButton from "..";

export default {
  title: "Common/RaisedButton",
  component: RaisedButton
} as Meta;

export const Default = () => <RaisedButton />;
