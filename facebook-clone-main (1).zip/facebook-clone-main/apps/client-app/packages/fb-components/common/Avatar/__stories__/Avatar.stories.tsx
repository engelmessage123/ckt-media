import { Meta } from "@storybook/react/types-6-0";
import Avatar from "..";

export default {
  title: "Common/Avatar",
  component: Avatar
} as Meta;

export const Default = () => <Avatar />;
