import { Meta } from "@storybook/react/types-6-0";
import RoundButton from "..";

export default {
  title: "Common/RoundButton",
  component: RoundButton
} as Meta;

export const Default = () => <RoundButton />;
